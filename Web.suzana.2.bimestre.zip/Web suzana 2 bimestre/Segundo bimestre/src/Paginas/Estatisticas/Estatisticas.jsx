import BarraNavegacao from "../../BarraDeNavegacao/BarraNavegacao"
import Rodape from "../../Rodapé/Rodape"
import "./Estatisticas.css"

function Estatisticas() {


return(

        <div className="Container">

    <BarraNavegacao />

    <h1>Relatórios de produtividade</h1>
    <div className="Produtividade">
        <p>Ultimos 7 dias : 519 Eventos marcados</p>
        <p>Ultimos 30 dias : 2590 Eventos marcados</p>
        <p>Ultimos 365 dias : 5540 Eventos marcados</p>
    </div>


    <Rodape />

</div>

)
}

export default Estatisticas