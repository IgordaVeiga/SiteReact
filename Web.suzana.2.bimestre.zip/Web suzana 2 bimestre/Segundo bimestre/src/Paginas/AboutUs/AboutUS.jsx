import BarraNavegacao from "../../BarraDeNavegacao/BarraNavegacao"
import Rodape from "../../Rodapé/Rodape"
import "./AboutUs.css"

function AboutUs(){

    return(
        <div className="Container">

            <BarraNavegacao />

            <div>
                <h1>Sobre o task flow</h1>
                <p>O Task flow nasceu da necessidade de ter um gerenciador de tarefas simples, rápido e focado em produtividade</p>
                <h2>Nossa missão</h2>
                <p>Simplificar a gestão de atividades diárias, juntando estudantes e profissionais a transformarem suas metas em ações concretas</p>
                <h2>Tecnologias utilizadas</h2>
                <ul className="Lista_About">
                    <li>React: Para a construção da Single Page Application (SPA).</li>
                    <li>React Router DOM: Para o controle eficiente de rotas.</li>
                    <li>CSS Modules: Para garantir a organização e o escopo local dos estilos.</li>
                    <li>Design Responsivo: Para usabilidade em qualquer dispositivo.</li>
                </ul>
            </div>
            <Rodape />
        </div>
    )

}

export default AboutUs