function ComoFunciona(){
    return(
        <div className="Container">
<h1>Como funciona ?</h1>
<h2>Criar uma tarefa</h2>
<p>A maior duvida que você deve ter agora é: Como utilizar esse app?</p>
<p>Este app foi feito com o objetivo de ser o mais intuitivo possível. Para utilizá-lo basta apenas colocar o nome da tarefa/evento , agendar um horário para realizá-lo e, por fim, apertar no botão enviar</p>
<h2>Apagar uma tarefa</h2>
<p>Para apagar uma tarefa que já foi concluida, basta apenas apertar na lixeira ao lado da tarefa</p>
        </div>
    )
}

export default ComoFunciona