import BarraNavegacao from "../../BarraDeNavegacao/BarraNavegacao"
import Rodape from "../../Rodapé/Rodape"
import "./Home.modular.css"
function Home() {



    return (
        <div>

            <BarraNavegacao />
            
            <header>
                <div className="Container">
                    <h1>Organize seu dia, conclua suas metas</h1>
                    <p>Gerencie todas as suas tarefas de forma simples e intuitiva</p>
                    {/*ADICIONAR ROTA DEPOIS */}
                    <p>Ver minhas tarefas</p>
                </div>
            </header>

            <section className="Sessao">
                <div className="Container">
                <h2>Por que tem o Task Flow?</h2>
                <div className="FeatureGrid">
                    <div className="FeatureCard">
                    <h3>Foco simples</h3>
                    <p>Interface limpa,sem distrações</p>
                    </div>
                    <div className="FeatureCard">
                        <h3>Responsivo</h3>
                        <p>Acesse e gerencie suas tarefas de qualquer dispositivo</p>
                    </div>
                    <div className="FeatureCard">
                        <h3>Sincronização</h3>
                        <p>Mantenha suas listas atualizadas em tempo real</p>
                    </div>
                </div>
                </div>
                
            </section>
            <Rodape />
        </div>
    )
}

export default Home