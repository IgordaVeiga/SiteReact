import {Link} from "react-router-dom"
import "./Rodape.modular.css"
function Rodape() {
    return (
        <div className="Container_Rodape">
                <hr />
            <nav className="Rodape">
                <ul className="Lista">
                    <li> <Link to={'/'}>Home</Link></li>
                    <li> <Link to={'/Sobre'}>Sobre-nós</Link></li>
                    <li><Link to={'/Funcionamento'}>Como funciona</Link></li>
                    <li><Link to={'/Estatisticas'}>Estatisticas</Link></li>
                </ul>
                
            </nav>
        </div>
    )
}

export default Rodape