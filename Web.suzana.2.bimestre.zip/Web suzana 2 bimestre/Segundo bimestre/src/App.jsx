import { BrowserRouter, Route, Routes} from "react-router-dom"
import './App.css'
import Home from "./Paginas/Home/Home"
import AboutUs from "./Paginas/AboutUs/AboutUS"
import Estatisticas from "./Paginas/Estatisticas/Estatisticas"
import ComoFunciona from "./Paginas/ComoFunciona/ComoFunciona"
import BarraNavegacao from "./BarraDeNavegacao/BarraNavegacao"
import Rodape from "./Rodapé/Rodape"

function App() {

  return (
    <div>

      <BrowserRouter>
      
      < BarraNavegacao />
      
      <Routes>
        <Route path='/' element={<Home />}/>
        <Route path='/Sobre' element={<AboutUs />}/>
        <Route path='/Funcionamento' element={<ComoFunciona />}/>
        <Route path='/Estatisticas' element={<Estatisticas />}/>
        <Route path='*' element={<h1>ERRO:PÁGINA NÃO ENCONTRADA</h1>}/>
      </Routes>

      <Rodape />

      </BrowserRouter>

    </div>
  )
}

export default App
