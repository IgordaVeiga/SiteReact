import "./BarraNavegacao.css"
import {Link} from "react-router-dom"

function BarraNavegacao() {
    return (
        <div>
            <nav className="Barra">
                <ul className="ListaNav">

                    <li> <Link to={'/'}>Home</Link></li>
                    <li> <Link to={'/Sobre'}>Sobre-nós</Link></li>
                    <li><Link to={'/Funcionamento'}>Como funciona</Link></li>
                    <li><Link to={'/Estatisticas'}>Estatisticas</Link></li>

                </ul>
            </nav>
            <hr></hr>
        </div>
    )
}
export default BarraNavegacao